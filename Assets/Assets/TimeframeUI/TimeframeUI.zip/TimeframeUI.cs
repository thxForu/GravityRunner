/// Generated all-in-one script file TimeframeUI.cs the Tue Dec 10 12:51:00 UTC 2019 from https://gitlab.com/TermWay/timeframeui/-/jobs/374787674.
/* LICENSE.md
Copyright (c) 2019 Termway

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/


/* README.txt
# TimeframeUI
A simple text and graph UI to monitor performance in Unity3D.

# Gitlab project page
The source code is available on the gitlab page project: https://gitlab.com/TermWay/timeframeui

# Supported Unity3D versions
This asset has been tested on Unity 5.6, 2017.4 LTS, 2018.4 LTS and 2019.2.

# Quick overview video
A short video showcasing this asset is available online: https://youtu.be/ssvVOzirybI 

# Quick setup
There are multiple ways to add this UI to your Unity3D project.

## Add the TimeframeUI component
Add the TimeframeUI component or drag and drop the TimeframeUI.cs file on a GameObject.

## Create from the Unity3D menu
From the menu GameObject > UI > Timeframe, it will create a new GameObject in the hierarchy.

# Features

## Global features
*  Toggle UI Key: short key to toggle the UI visibility. Visibility does not stop the recording of the time frame values.
*  Default visibility of the UI which is the visibility on the editor and the visibility on the first frame of the application.
*  Stats Frame Range: latest frame number used to compute statistics on.
*  Target Framerate: force the frame rate value. The zero value means that there is no forced frame rate.
*  UI Anchor Position: anchor to snap the UI at one corner:
   *  (0,0) is bottom left,
   *  (0,1) is bottom right,
   *  (1,0) is top left,
   *  (1,1) is top right.
    Will rebuild the UI.
*  UI Offset: UI absolute global offset in pixel according to the anchor position. Will rebuild the UI.

## Grid features
Displays the latest statistics values in a text grid.

*  Update delay: delay in second between each value update of the grid.
*  Show legend: visibility of the legend row and column. Will rebuild the UI.
*  Show ms: visibility of the time frame (millisecond) column. Will rebuild the UI.
*  Show fps: visibility of the frame rate (frame per second) column. Will rebuild the UI.
*  Grid Cell Size: cell size of the grid in pixel. Will resize the grid. Will rebuild the UI.
*  Grid Rows Data: statistics to include in the grid display in the given order. Each data is a row in the grid:
   *  Stats Type to be computed among min, max, current, average and percentile.
      -  Average: compute the average from the last recorded values specified. The zero value force all recorded values to be used.
      -  Current: compute the average from the last recorded values specified. The zero value force the current time frame to be used.
      -  Min: get the minimal time frame recorded.
      -  Max: get the maximal time frame recorded.
      -  Percentile: compute the percentile given value of all recorded values.
   *  Value: statistics parameter.
   *  Graph Representation: point (line) or bar (histogram) rendering. None disables the graph representation.
   *  Apply Color To Text: if the color is also applied to the grid.
   *  Color:  color used on the graph for this statistic.
   *  Color Operation: how color is painted over previous statistics on the graph.
      Will rebuild the UI.

## Graph features
Displays the latest statistics values in a histogram graph.

*  Show graph: visibility of the graph. Will rebuild the UI.
*  Graph Auto Resize: automatic resize of the width when the resolution changed. Will rebuild the graph.
*  Graph Width: width of the graph. If the auto resize option is activated and the value set to zero the graph will take all the available width space. Will rebuild the graph.
*  Graph Texture Size: texture size of the graph. Each column on the X axis has a unique statistic value. Should be below Stats Frame Range value. Will recreate the graph texture. 
*  Graph Ms Upper Limit: upper limit of Y axis of the graph in millisecond. The zero value means it's computed as twice the current median. Will recreate the graph texture.
*  Graph Color Alternate Tint: tint color of the graph used to contrast new override painted value. Tint is multiplied to all the color painted.

Manual configuration can also be done once the UI is generated. For example the background color and texts style. Some feature will rebuild the UI and manual modification will be lost in that case.

# All-in-one script file
An all-in-one file is also included in the TimeframeUI.cs.zip file. To use it, remove every C# scripts of this asset and unzip the all-in-one TimeframeUI.cs file.

# UI generation
TimeframeUI used the Unity3D native UI to render all information. Individual UI.Text for each value and a UI.Image to display the graph via a texture updated each frame with different values.

## Hierarchy 
There are three mains objects:  
*  A screen space canvas to display the UI and served as a parent GameObject for the two following element.
*  A container for the grid information which has all statistics in different texts components.
*  An image to display the graph thanks to a texture where a column is updated each frame.

```
TimeFrameUI (TimeframeUI)
├─ Canvas (UI.Canvas)
|  ├─ GridImage (UI.Image, UI.GridLayoutGroup)
|  |  ├─  Legend_Legend (UI.Text)
|  |  ├─  Legend_Stats_1  (UI.Text)
|  |  ├─  ...
|  |  ├─  Legend_Stats_N  (UI.Text)

|  |  ├─  Ms_Ms  (UI.Text)
|  |  ├─  Ms_Stats_1  (UI.Text)
|  |  ├─  ...
|  |  ├─  Ms_Stats_N  (UI.Text)

|  |  ├─  Fps_Fps  (UI.Text)
|  |  ├─  Fps_Stats_1  (UI.Text)
|  |  ├─  ...
|  |  ├─  Fps_Stats_N  (UI.Text)
|  ├─ GraphImage (UI.Image)
```
There are variations in the GridImage GameObject depending on the current TimeframeUI configuration.

# Performances
The most important factor to improve performances is to reduce the size of the graph texture. A small texture (< 20k pixels, 256x64) takes less than a millisecond to render on most systems but a larger texture (> 100k pixels) takes longer. A very high Stats Frame Range value will also drop performances.

*/


/// timeframeui/Assets/TimeframeUI/Scripts/TimeframeUI.cs
﻿using Termway.Helper;

using System;
using System.Linq;
using System.Collections.Generic;

using UnityEngine;
using UnityEngine.UI;

namespace Termway.TimeframeUI
{
    /// <summary>
    /// UI that show a grid and graph with timeframe performance in milliseconds (ms) and frame per seconds (fps).
    /// Drag and drop the file on a gameObject and rebuild the ui or add it from the menu GameObject > UI > Timeframe.
    /// </summary>
    [HelpURL("https://gitlab.com/TermWay/timeframeui")]
    [AddComponentMenu("UI/Timeframe")]
    [DisallowMultipleComponent]
    public class TimeframeUI : MonoBehaviour
    {
        public enum StatsFormat
        {
            Legend,
            Ms,
            Fps
        }

        /// <summary>
        /// Max value displayed by the grid.
        /// </summary>
        const uint MAX_GRID_VALUE = 9999;

        [Tooltip("Short key to toggle the UI visibility. Visibility does not stop the recording of the time frame values.")]
        public KeyCode toggleUiKey = KeyCode.F2;

        [Tooltip("Default visibility of the UI which is the visibility on the editor and the visibility on the first frame of the application.")]
        public bool defaultVisibility = true;

        [Tooltip("Latest frame number used to compute statistics on.")]
        public uint statsFrameRange = 2048;

        [Tooltip("Force the frame rate value. The zero value means that there is no forced frame rate.")]
        public uint targetFramerate = 0;

        [Tooltip(@"Anchor to snap the UI at one corner. Will rebuild the UI.
    - (0,0) is bottom left,
    - (0,1) is bottom right,
    - (1,0) is top left,
    - (1,1) is top right.")]
        [Vector2IntRange(0, 1)]
        public Vector2Int uiAnchorPosition = new Vector2Int(0, 1);

        [Tooltip("UI absolute global offset in pixel according to the anchor position. Will rebuild the UI.")]
        [Vector2IntRange(-8192, 8192)]
        public Vector2Int uiOffset;


        [Header("Grid")]
        [Tooltip("Delay in second between each value update of the grid.")]
        public float gridUpdateDelaySeconds = 1;

        [Tooltip("Visibility of the legend row and column. Will rebuild the UI.")]
        public bool showLegend = true;

        [Tooltip("Visibility of the time frame (millisecond) column. Will rebuild the UI.")]
        public bool showMs = true;

        [Tooltip("Visibility of the frame rate (frame per second) column. Will rebuild the UI.")]
        public bool showFps = true;

        [Tooltip("Cell size of the grid in pixel. Will resize the grid. Will rebuild the UI.")]
        [Vector2Range(7, 200, 5, 200)]
        public Vector2 gridCellSize = new Vector2(35, 17);

        [Tooltip("Statistics to include in the grid display in the given order. Each data is a row in the grid.")]
        public GridRow[] gridRowsData;


        [Header("Graph")]
        [Tooltip("Visibility of the graph. Will rebuild the UI.")]
        public bool showGraph = true;

        [Tooltip("Automatic resize of the width when the resolution changed. Will rebuild the graph.")]
        public bool graphWidthAutoResize = false;

        [Tooltip("Width of the graph. If the auto resize option is activated and the value set to zero the graph will take all the available width space. Will rebuild the graph.")]
        public uint graphWidth = 256;

        [Tooltip("texture size of the graph. Each column on the X axis has a unique statistic value. Should be below Stats Frame Range value. Will recreate the graph texture.")]
        [Vector2IntRange(2, 8192)]
        public Vector2Int graphTextureSize = new Vector2Int(256, 64);

        [Tooltip("Upper limit of Y axis of the graph in millisecond. The zero value means it's computed as twice the current median. Will recreate the graph texture.")]
        public uint graphMsUpperLimit = 0;

        [Tooltip("Tint color of the graph used to contrast new override painted value. Tint is multiplied to all the color painted.")]
        public Color graphColorAlternateTint = Color.white - Color.black * 0.3f;


        [SerializeField] GameObject canvasGameObject;
        [SerializeField] Image gridImage;
        [SerializeField] Image graphImage;
        [SerializeField] GridLayoutGroup gridLayoutGroup;
        [SerializeField] Texture2D texture;
        Color[] pixelsColor;

        Color clearColor = Color.clear; //Because static Color are not cached. 

        /// <summary>
        /// Reduce string allocation at runtime.
        /// [0, MAX_VALUE.9] => 10 * <see cref="MAX_GRID_VALUE"/> values. 
        /// </summary>
        string[] cachedFloatString;

        uint graphCurrentColumn;
        float timeSinceLastGridUpdate;

        Stats stats;


        /// <summary>
        /// Columns count of the grid ui. +1 for the legend.
        /// </summary>
        int GridColumnCount { get { return (showLegend ? 1 : 0) + (showMs ? 1 : 0) + (showFps ? 1 : 0); } }

        /// <summary>
        /// Rows count of the grid ui. +1 for the legend.
        /// </summary>
        int RowCount { get { return gridRowsData.Length + (showLegend ? 1 : 0); } }

#if UNITY_EDITOR
        [UnityEditor.MenuItem("GameObject/UI/Timeframe")]
        static void CreateAndAddUI()
        {
            GameObject timeframeGameObject = new GameObject(typeof(TimeframeUI).Name);
            UnityEditor.Undo.RegisterCreatedObjectUndo(timeframeGameObject, "TimeframeUI");
            TimeframeUI timeframeUI = UnityEditor.Undo.AddComponent<TimeframeUI>(timeframeGameObject);
            timeframeUI.BuildUI();
        }
#endif

        [ContextMenu("Default Stats", false, 1001)]
        void DefaultStatsThenBuildUI()
        {
            gridRowsData = new GridRow[]
            {
                new GridRow(GridRow.StatsType.Current, 50, GridRow.GraphRepresentation.BarFromBottom),
                new GridRow(GridRow.StatsType.Average),
                new GridRow(GridRow.StatsType.Percentile, 50),
                new GridRow(GridRow.StatsType.Percentile, 10),
                new GridRow(GridRow.StatsType.Percentile, 01),
            };
            BuildUI();
        }


        [ContextMenu("Full Stats with color", false, 1002)]
        void FullStatsThenBuildUI()
        {
            gridRowsData = new GridRow[]
            {
                new GridRow(GridRow.StatsType.Current, 50, GridRow.GraphRepresentation.BarFromBottom, Color.black * 0.7f),
                new GridRow(GridRow.StatsType.Average, 0, GridRow.GraphRepresentation.Point, new Color(0, 81f / 255, 188f / 255), true,  GridRow.ColorOperation.Blend),
                new GridRow(GridRow.StatsType.Min),
                new GridRow(GridRow.StatsType.Percentile, 99, GridRow.GraphRepresentation.BarFromBottom, new Color(128f / 255, 0, 0), true, GridRow.ColorOperation.Blend),
                new GridRow(GridRow.StatsType.Percentile, 90),
                new GridRow(GridRow.StatsType.Percentile, 50),
                new GridRow(GridRow.StatsType.Percentile, 10),
                new GridRow(GridRow.StatsType.Percentile, 01),
                new GridRow(GridRow.StatsType.Max)
            };
            BuildUI();
        }

        [ContextMenu("Minimal stats", false, 1003)]
        void MinimalStatsThenBuildUI()
        {
            gridRowsData = new GridRow[]
            {
                new GridRow(GridRow.StatsType.Current, 50, GridRow.GraphRepresentation.BarFromBottom),
                new GridRow(GridRow.StatsType.Average, 0, GridRow.GraphRepresentation.Point),
                new GridRow(GridRow.StatsType.Percentile, 01, GridRow.GraphRepresentation.Point),
            };
            BuildUI();
        }

        /// <summary>
        /// Destroy all children and rebuild ui.
        /// </summary>
        [ContextMenu("Rebuild UI", false, 1021)]
        internal void BuildUI()
        {
            //Remove canvas child game object.
            if (canvasGameObject)
                GameObject.DestroyImmediate(canvasGameObject);

            Transform canvasTransform = transform.Find("Canvas_" + typeof(TimeframeUI).Name);
            if (canvasTransform != null && canvasTransform.gameObject.GetComponent<Canvas>() != null)         
                GameObject.DestroyImmediate(canvasTransform.gameObject);

            foreach (GridRow displayedEntry in gridRowsData)
                displayedEntry.Texts.Clear();

            canvasGameObject = new GameObject("Canvas_" + typeof(TimeframeUI).Name);
            canvasGameObject.transform.parent = gameObject.transform;
            Canvas canvas = canvasGameObject.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;

            GameObject gridImageGameObject = new GameObject("GridImage");
            gridImageGameObject.transform.parent = canvasGameObject.transform;
            gridImage = gridImageGameObject.AddComponent<Image>();
            gridImage.rectTransform.anchorMin = uiAnchorPosition;
            gridImage.rectTransform.anchorMax = uiAnchorPosition;
            gridImage.color = new Color(0.2f, 0.2f, 0.2f, 0.2f);

            if (showGraph)
            {
                GameObject graphImageGameObject = new GameObject("GraphImage");
                graphImageGameObject.transform.parent = canvasGameObject.transform;
                graphImage = graphImageGameObject.AddComponent<Image>();
                graphImage.rectTransform.anchorMin = uiAnchorPosition;
                graphImage.rectTransform.anchorMax = uiAnchorPosition;
            }

            if (GridColumnCount > 0)
            {
                gridLayoutGroup = gridImageGameObject.AddComponent<GridLayoutGroup>();
                gridLayoutGroup.cellSize = gridCellSize;
                gridLayoutGroup.startAxis = GridLayoutGroup.Axis.Vertical;
                gridLayoutGroup.constraint = GridLayoutGroup.Constraint.FixedRowCount;
                gridLayoutGroup.constraintCount = RowCount;
            }

            if (showLegend)
                CreateTexts(gridImage, StatsFormat.Legend, FontStyle.Bold);

            if (showMs)
                CreateTexts(gridImage, StatsFormat.Ms);

            if (showFps)
                CreateTexts(gridImage, StatsFormat.Fps);

            ResizeGridUI();
            SetUiState(defaultVisibility);
            InitTexture();

            if (Application.isPlaying)
            {
                UpdateGrid();
                UpdateAllTextureColumns();
            }
        }

        [ContextMenu("Resize grid UI", false, 1022)]
        internal void ResizeGridUI()
        {
            if (GridColumnCount > 0)
                gridLayoutGroup.cellSize = gridCellSize;

            gridImage.rectTransform.sizeDelta = new Vector2(gridCellSize.x * GridColumnCount, gridCellSize.y * RowCount);
            int signX = uiAnchorPosition.x == 0 ? 1 : -1;
            int signY = uiAnchorPosition.y == 0 ? 1 : -1;
            gridImage.rectTransform.anchoredPosition = new Vector2(
                signX * gridImage.rectTransform.sizeDelta.x / 2 + uiOffset.x,
                signY * gridImage.rectTransform.sizeDelta.y / 2 - uiOffset.y);

            if (showGraph)
                ResizeGraphUI();
        }

        [ContextMenu("Resize graph UI", false, 1023)]
        internal void ResizeGraphUI()
        {
            if (showGraph)
            {
                int negIfAnchorIsTop = uiAnchorPosition.y == 1 ? -1 : 1;
                int negIfAnchorIsRight = uiAnchorPosition.x == 1 ? -1 : 1;

                // Graph size is the given graph width and the computed grid height.
                if (graphWidthAutoResize)
                {
                    graphImage.rectTransform.anchorMin = new Vector2(0, uiAnchorPosition.y);
                    graphImage.rectTransform.anchorMax = new Vector2(1, uiAnchorPosition.y);

                    float offsetFromBorderGridSide = gridImage.rectTransform.sizeDelta.x + uiOffset.x * negIfAnchorIsRight;
                    float offsetFromOtherBorder = graphWidth <= 0 ? 0 : GameWindowResolution.x - gridImage.rectTransform.sizeDelta.x - graphWidth - uiOffset.x * negIfAnchorIsRight;
                    graphImage.rectTransform.Left(uiAnchorPosition.x == 0 ? offsetFromBorderGridSide : offsetFromOtherBorder);
                    graphImage.rectTransform.Right(uiAnchorPosition.x == 0 ? offsetFromOtherBorder : offsetFromBorderGridSide);
                    graphImage.rectTransform.Height(gridImage.rectTransform.sizeDelta.y);
                    graphImage.rectTransform.PosY(negIfAnchorIsTop * gridImage.rectTransform.sizeDelta.y / 2 - uiOffset.y);
                }
                else
                {
                    int subWidthIfAnchorIsRight = uiAnchorPosition.x == 1 ? -(int)graphWidth : 0;

                    graphImage.rectTransform.anchoredPosition = new Vector2(
                        subWidthIfAnchorIsRight + negIfAnchorIsRight * gridImage.rectTransform.sizeDelta.x + graphWidth / 2 + uiOffset.x,
                        negIfAnchorIsTop * gridImage.rectTransform.sizeDelta.y / 2 - uiOffset.y);
                    graphImage.rectTransform.sizeDelta = new Vector2(graphWidth, gridImage.rectTransform.sizeDelta.y);
                }
            }
        }

        void CreateTexts(Image image, StatsFormat statsFormat, FontStyle fontStyle = FontStyle.Italic)
        {
            string prefixName = statsFormat.ToString();
            if (showLegend)
            {
                GameObject textGameObject = new GameObject(prefixName + "_" + statsFormat);
                textGameObject.transform.parent = image.transform;
                Text text = textGameObject.AddComponent<Text>();
                text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                text.text = GetLegendFromStatFormat(statsFormat);
                text.color = Color.black;
                text.resizeTextForBestFit = true;
                text.resizeTextMinSize = 1;
                text.alignment = TextAnchor.MiddleCenter;
            }

            foreach (GridRow gridRow in gridRowsData)
            {
                GameObject textGameObject = new GameObject(prefixName + "_" + gridRow.statsType + gridRow.Value);
                textGameObject.transform.parent = image.transform;
                Text text = textGameObject.AddComponent<Text>();
                text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                text.color = gridRow.ApplyColorToText ? gridRow.Color : Color.black;
                text.fontStyle = fontStyle;
                text.text = statsFormat == StatsFormat.Legend ? GetDisplayEntryLegend(gridRow) : "###";
                text.resizeTextForBestFit = true;
                text.resizeTextMinSize = 4;
                text.alignment = statsFormat == StatsFormat.Legend ? TextAnchor.MiddleLeft : TextAnchor.MiddleCenter;
                gridRow.Texts.Add(text);
            }
        }

        string GetLegendFromStatFormat(StatsFormat statFormat)
        {
            switch (statFormat)
            {
                case StatsFormat.Fps:
                    return "fps";
                case StatsFormat.Ms:
                    return "ms";
                default:
                    return "";
            }
        }

        string GetDisplayEntryLegend(GridRow entry)
        {
            switch (entry.statsType)
            {
                case GridRow.StatsType.Current:
                    return "cur";
                case GridRow.StatsType.Average:
                    return "avg";
                case GridRow.StatsType.Percentile:
                    return entry.Value + "%";
                case GridRow.StatsType.Min:
                    return "min";
                case GridRow.StatsType.Max:
                    return "max";
                default:
                    return "";
            }
        }

        void Reset()
        {
            //Recover canvasGameObject lost by the reset.
            Canvas[] canvas = GetComponentsInChildren<Canvas>();
            foreach (Canvas canva in canvas)
                if (canva.gameObject.name == "Canvas_" + typeof(TimeframeUI).Name)
                {
                    if (canvasGameObject != null) // Remove possible duplicate
                        DestroyImmediate(canvasGameObject);
                    canvasGameObject = canva.gameObject;
                }
            DefaultStatsThenBuildUI();
        }

        void Start()
        {
            if (statsFrameRange < graphTextureSize.x)
                Debug.LogWarningFormat("{0} is below {1} x size and performance is wasted. " +
                    "You can either reduce the {1} x or increase the {0}. {0} < {1}.",
                    Name.Of(() => statsFrameRange), Name.Of(() => graphTextureSize));

            if(targetFramerate != 0)
                Application.targetFrameRate = (int) targetFramerate;

            if (canvasGameObject == null)
                Debug.LogError("The reference of the canvas GameObject is lost. Please Rebuild the UI.");

            InitStats();
            InitTexture();
            InitPixelColors();
            CreateCachedFloatString();
            CorrectGridUpdateDelay();
            UpdateGrid();
        }

        internal void CorrectGridUpdateDelay()
        {
            gridUpdateDelaySeconds = Math.Max(0.01f, gridUpdateDelaySeconds); //Min attribute is buggy.
        }

        internal void InitStats()
        {
            if (Application.isPlaying)
                stats = new Stats(Math.Max(1, statsFrameRange));
        }

        void InitPixelColors()
        {
            pixelsColor = new Color[graphTextureSize.x * graphTextureSize.y];
            for (int c = 0; c < pixelsColor.Length; c++)
                pixelsColor[c] = Color.clear;
        }

        internal void InitTexture()
        {
            InitPixelColors();
            texture = new Texture2D(graphTextureSize.x, graphTextureSize.y, TextureFormat.RGBA32, false); //Mipmap needs to be disable to avoid blur.
            texture.filterMode = FilterMode.Point; //Give sharp pixel aspect. Remove to smooth the graph renderer.

            if (showGraph)
                graphImage.sprite = Sprite.Create(texture,
                    new Rect(0, 0, texture.width, texture.height),
                    new Vector2(0f, 0f), 10f);

            //Create initial line color for graph part.
            int start = graphTextureSize.x * (graphTextureSize.y / 2);
            int end = start + graphTextureSize.x;
            for (int c = start; c < end; c++)
                pixelsColor[c] = Color.black * graphColorAlternateTint;
            texture.SetPixels(pixelsColor, 0);
            texture.Apply();
        }

        void CreateCachedFloatString()
        {
            uint totalSize = (MAX_GRID_VALUE + 1) * 10;
            cachedFloatString = new string[totalSize];
            for (int i = 0; i < totalSize; i++)
                cachedFloatString[i] = (i / 10f).ToString("R1");
        }

        void Update()
        {
            UpdateTimeframe();

            if (Input.GetKeyDown(toggleUiKey))
                ToggleUI();

            UpdateGraph();

            if (Time.time - timeSinceLastGridUpdate > gridUpdateDelaySeconds)
                UpdateGrid();
        }

        void UpdateTimeframe()
        {
            stats.AddNext(Time.unscaledDeltaTime * 1000f); // s -> ms
        }

        internal void UpdateGrid()
        {
            if (canvasGameObject.activeSelf)
            {
                int msIndex = showLegend ? 1 : 0;
                int fpsIndex = msIndex + (showMs ? 1 : 0);

                foreach (GridRow displayedEntry in gridRowsData)
                {
                    if (showMs)
                        displayedEntry.Texts[msIndex].text = FloatToString(ComputeDisplayStatValue(displayedEntry));

                    if (showFps)
                        displayedEntry.Texts[fpsIndex].text = FloatToString(1000f / ComputeDisplayStatValue(displayedEntry), false);
                }
                timeSinceLastGridUpdate = Time.time;
            }
        }

        string FloatToString(float f, bool hasDigit = true)
        {
            if (f > MAX_GRID_VALUE)
                return cachedFloatString.Last();
            //1 digit 
            double d = Math.Round((double)f, hasDigit ? 1 : 0);
            int index = (int)(d * 10);
            return cachedFloatString[index];
        }

        void ToggleUI()
        {
            canvasGameObject.SetActive(!canvasGameObject.activeSelf);
        }

        internal void SetUiState(bool state)
        {
            foreach (Transform child in transform)
                child.gameObject.SetActive(state);
        }

        void UpdateGraph()
        {
            if (showGraph && canvasGameObject.activeSelf)
            {
                graphCurrentColumn++;
                if (graphCurrentColumn / graphTextureSize.x >= 2)
                    graphCurrentColumn = 0;

                ClearTextureColumn(GetGraphColumnIndex);
                UpdateTextureColumnPixels(GetGraphColumnIndex);

                texture.SetPixels(pixelsColor, 0);
                texture.Apply();
            }
        }

        internal void RecreateTexture()
        {
            InitTexture();
            UpdateAllTextureColumns();
        }

        internal void UpdateAllTextureColumns()
        {
            if (Application.isPlaying)
            {
                for (uint x = 0; x < graphTextureSize.x; x++)
                {
                    ClearTextureColumn(x);
                    UpdateTextureColumnPixels(x);
                }
            }
        }

        void ClearTextureColumn(uint x)
        {
            for (int y = 0; y < graphTextureSize.y; y++)
            {
                int index = ((int)x % graphTextureSize.x) + y * graphTextureSize.x;
                pixelsColor[index] = clearColor;
            }
        }

        void UpdateTextureColumnPixels(uint x, bool ShouldCurrentStatsOnlyTakeRealTimeframeValueAndNotAverageOne = true)
        {
            foreach (GridRow gridRow in gridRowsData)
            {
                float value = ComputeDisplayStatValue(gridRow);

                if (ShouldCurrentStatsOnlyTakeRealTimeframeValueAndNotAverageOne && gridRow.statsType == GridRow.StatsType.Current)
                {
                    uint lastNValue = x > GetGraphColumnIndex ? GetGraphColumnIndex + (uint)graphTextureSize.x - x : GetGraphColumnIndex - x;
                    value = stats.Last(lastNValue);
                }


                switch (gridRow.graphRepresentation)
                {
                    case GridRow.GraphRepresentation.BarFromBottom:
                    case GridRow.GraphRepresentation.BarFromTop:
                        UpdateTextureColumnPixelsBar(x, value, gridRow);
                        break;
                    case GridRow.GraphRepresentation.Point:
                        UpdateTextureColumnPixelsPoint(x, value, gridRow);
                        break;
                    default:
                        break;
                }
            }
        }

        uint GetGraphColumnIndex
        {
            get
            {
                return (uint)(graphCurrentColumn % graphTextureSize.x);
            }
        }


        void UpdateTextureColumnPixelsBar(uint x, float value, GridRow gridRow)
        {
            Color graphColor = gridRow.Color * GetTintColor(graphCurrentColumn, x);
            // FIXME? Variable upper limit make the graph wrong for previous values.
            float max = CurrentUpperLimit;
            int y = Mathf.Min(graphTextureSize.y - 1, (int)(value * graphTextureSize.y / max));
            if (gridRow.graphRepresentation == GridRow.GraphRepresentation.BarFromBottom)
                for (int p = 0; p <= y; p++)
                    SetTexturePixel(x, p, gridRow, graphColor);

            else
                for (int p = graphTextureSize.y - 1; p >= y; p--)
                    SetTexturePixel(x, p, gridRow, graphColor);
        }

        void SetTexturePixel(uint x, int y, GridRow gridRow, Color graphColor)
        {
            int index = ((int)x % graphTextureSize.x) + y * graphTextureSize.x;
            pixelsColor[index] = gridRow.PerformColorOperation(pixelsColor[index], graphColor);
        }

        void UpdateTextureColumnPixelsPoint(uint x, float value, GridRow gridRow)
        {
            Color graphColor = gridRow.Color * GetTintColor(graphCurrentColumn, x);
            int y = Mathf.Min(graphTextureSize.y - 1, (int)(value * graphTextureSize.y / CurrentUpperLimit));
            int index = ((int)x % graphTextureSize.x) + y * graphTextureSize.x;
            pixelsColor[index] = gridRow.PerformColorOperation(pixelsColor[index], graphColor);
        }

        Color GetTintColor(uint currentColumn, uint columnToUpdate)
        {
            if ((currentColumn / graphTextureSize.x) % 2 == 0)
                return currentColumn % graphTextureSize.x < columnToUpdate ? graphColorAlternateTint : Color.white;
            else
                return currentColumn % graphTextureSize.x < columnToUpdate ? Color.white : graphColorAlternateTint;
        }

        float CurrentUpperLimit
        {
            get
            {
                return graphMsUpperLimit == 0 ? stats.Percentile(50) * 2 : graphMsUpperLimit;
            }
        }

        float ComputeDisplayStatValue(GridRow displayStat)
        {
            switch (displayStat.statsType)
            {
                case GridRow.StatsType.Current:
                    return displayStat.Value == 0 ? stats.LastAdded : stats.Average((uint)displayStat.Value);
                case GridRow.StatsType.Average:
                    return stats.Average((uint)displayStat.Value);
                case GridRow.StatsType.Percentile:
                    return stats.Percentile(displayStat.Value);
                case GridRow.StatsType.Min:
                    return stats.Min;
                case GridRow.StatsType.Max:
                    return stats.Max;
                default:
                    return 0;
            }
        }

        Vector2 GameWindowResolution
        {
            get
            {
#if UNITY_EDITOR
                return UnityEditor.Handles.GetMainGameViewSize();
#else
                return new Vector2(Screen.width, Screen.height);
#endif
            }
        }

        [Serializable]
        public class GridRow
        {
            public enum StatsType
            {
                Current,
                Average,
                Percentile,
                Min,
                Max
            }

            public enum GraphRepresentation
            {
                None,
                BarFromBottom,
                BarFromTop,
                Point
            }

            public enum ColorOperation
            {
                Replace,
                Add,
                Sub,
                Mul,
                Min,
                Max,
                Blend
            }

            [Tooltip(@"Statistics type to be computed among min, max, current, average and percentile.
        ▪ Average: compute the average from the last recorded values specified. The zero value force all recorded values to be used.
        ▪ Current: compute the average from the last recorded values specified. The zero value force the current time frame to be used.
        ▪ Min: get the minimal time frame recorded.
        ▪ Max: get the maximal time frame recorded.
        ▪ Percentile: compute the percentile given value of all recorded values.")]
            public StatsType statsType;

            [Tooltip("Statistic parameter.")]
            public float Value;

            [Tooltip("Point (line) or bar (histogram) rendering. None disables the graph representation.")]
            public GraphRepresentation graphRepresentation;

            [Tooltip("If the color is also applied to the grid.")]
            public bool ApplyColorToText;

            [Tooltip("Color used on the graph for this statistic.")]
            public Color Color;

            [Tooltip("How color is painted over previous statistics on the graph.")]
            public ColorOperation colorOperation;

            [SerializeField, HideInInspector]
            internal List<Text> Texts;

            public GridRow(StatsType statsType,
                float value = 0,
                GraphRepresentation graphRepresentation = GraphRepresentation.None,
                Color? color = null, //default(Color) is 0,0,0,0 which is not practical.
                bool applyColorToText = false,
                ColorOperation colorOperation = ColorOperation.Replace)
            {
                this.statsType = statsType;
                Value = value;
                this.graphRepresentation = graphRepresentation;
                ApplyColorToText = applyColorToText;
                this.colorOperation = colorOperation;
                Color = color.HasValue ? color.Value : Color.black;
                Texts = new List<Text>();
            }

            public Color PerformColorOperation(Color fg, Color bg)
            {
                switch (colorOperation)
                {
                    case ColorOperation.Add: return bg + fg;
                    case ColorOperation.Sub: return bg - fg;
                    case ColorOperation.Mul: return bg * fg;

                    case ColorOperation.Min:
                        return new Color(
                           Mathf.Min(bg.r, fg.r),
                           Mathf.Min(bg.g, fg.g),
                           Mathf.Min(bg.b, fg.b),
                           Mathf.Min(bg.a, fg.a));

                    case ColorOperation.Max:
                        return new Color(
                           Mathf.Max(bg.r, fg.r),
                           Mathf.Max(bg.g, fg.g),
                           Mathf.Max(bg.b, fg.b),
                           Mathf.Max(bg.a, fg.a));

                    //https://stackoverflow.com/a/727339/985714
                    /*  newColor => foreground , currentColor => background
                        r.R = fg.R * fg.A / r.A + bg.R * bg.A * (1 - fg.A) / r.A; 
                        r.G = fg.G * fg.A / r.A + bg.G * bg.A * (1 - fg.A) / r.A; 
                        r.B = fg.B * fg.A / r.A + bg.B * bg.A * (1 - fg.A) / r.A;
                        r.A = 1 - (1 - fg.A) * (1 - bg.A);
                        */
                    case ColorOperation.Blend:
                        float rA = 1 - (1 - fg.a) * (1 - bg.a);
                        return new Color(
                            fg.r * fg.a / rA + bg.r * bg.a * (1 - fg.a) / rA,
                            fg.g * fg.a / rA + bg.g * bg.a * (1 - fg.a) / rA,
                            fg.b * fg.a / rA + bg.b * bg.a * (1 - fg.a) / rA,
                            rA);

                    case ColorOperation.Replace:
                    default:
                        return bg;
                }

            }
        }
    }
}


/// timeframeui/Assets/TimeframeUI/Scripts/TimeframeUIEditor.cs
﻿#if UNITY_EDITOR
namespace Termway.TimeframeUI
{
    using Termway.Helper;

    using System;
    using UnityEngine;
    using UnityEditor;

    [CustomEditor(typeof(TimeframeUI))]
    [CanEditMultipleObjects]
    public class TimeframeEditor : Editor
    {
        TimeframeUI timeframeUI;
        SerializedPropertyManager pm;

        SerializedProperty toggleUiKey;
        SerializedProperty defaultVisibility;
        SerializedProperty statsFrameRange;
        SerializedProperty targetFramerate;
        SerializedProperty uiAnchorPosition;
        SerializedProperty uiOffset;

        SerializedProperty gridUpdateDelaySeconds;
        SerializedProperty showLegend;
        SerializedProperty showMs;
        SerializedProperty showFps;
        SerializedProperty gridCellSize;
        SerializedProperty gridRowsData;

        SerializedProperty showGraph;
        SerializedProperty graphWidthAutoResize;
        SerializedProperty graphWidth;
        SerializedProperty graphTextureSize;
        SerializedProperty graphMsUpperLimit;
        SerializedProperty graphColorAlternateTint;

        void OnEnable()
        {
            timeframeUI = (TimeframeUI)target;

            toggleUiKey = serializedObject.FindProperty(Name.Of(() => timeframeUI.toggleUiKey));
            defaultVisibility = serializedObject.FindProperty(Name.Of(() => timeframeUI.defaultVisibility));
            statsFrameRange = serializedObject.FindProperty(Name.Of(() => timeframeUI.statsFrameRange));
            targetFramerate = serializedObject.FindProperty(Name.Of(() => timeframeUI.targetFramerate));
            uiAnchorPosition = serializedObject.FindProperty(Name.Of(() => timeframeUI.uiAnchorPosition));
            uiOffset = serializedObject.FindProperty(Name.Of(() => timeframeUI.uiOffset));

            gridUpdateDelaySeconds = serializedObject.FindProperty(Name.Of(() => timeframeUI.gridUpdateDelaySeconds));
            showLegend = serializedObject.FindProperty(Name.Of(() => timeframeUI.showLegend));
            showMs = serializedObject.FindProperty(Name.Of(() => timeframeUI.showMs));
            showFps = serializedObject.FindProperty(Name.Of(() => timeframeUI.showFps));
            gridCellSize = serializedObject.FindProperty(Name.Of(() => timeframeUI.gridCellSize));
            gridRowsData = serializedObject.FindProperty(Name.Of(() => timeframeUI.gridRowsData));

            showGraph = serializedObject.FindProperty(Name.Of(() => timeframeUI.showGraph));
            graphWidthAutoResize = serializedObject.FindProperty(Name.Of(() => timeframeUI.graphWidthAutoResize));
            graphWidth = serializedObject.FindProperty(Name.Of(() => timeframeUI.graphWidth));
            graphTextureSize = serializedObject.FindProperty(Name.Of(() => timeframeUI.graphTextureSize));
            graphMsUpperLimit = serializedObject.FindProperty(Name.Of(() => timeframeUI.graphMsUpperLimit));
            graphColorAlternateTint = serializedObject.FindProperty(Name.Of(() => timeframeUI.graphColorAlternateTint));

            Action buildUiAction = () => timeframeUI.BuildUI();

            pm = new SerializedPropertyManager(serializedObject);
            pm.Add(toggleUiKey);
            pm.Add(defaultVisibility, () => timeframeUI.SetUiState(defaultVisibility.boolValue));
            pm.Add(statsFrameRange, () => timeframeUI.InitStats());

            string tooltip = timeframeUI.GetType().GetField(Name.Of(() => timeframeUI.targetFramerate)).GetTooltip();
            pm.Add(targetFramerate,
                () => Application.targetFrameRate = (int)timeframeUI.targetFramerate,
                () => targetFramerate.intValue = EditorGUILayout.DelayedIntField(new GUIContent("Target Framerate", tooltip), targetFramerate.intValue));
            pm.Add(uiAnchorPosition, buildUiAction);
            pm.Add(uiOffset, buildUiAction);

            pm.Add(gridUpdateDelaySeconds, "Update Delay (s)", () => timeframeUI.CorrectGridUpdateDelay());
            pm.Add(showLegend, buildUiAction);
            pm.Add(showMs, buildUiAction);
            pm.Add(showFps, buildUiAction);
            pm.Add(gridCellSize, () => timeframeUI.ResizeGridUI());
            pm.Add(gridRowsData, buildUiAction);

            pm.Add(showGraph, buildUiAction);
            pm.Add(graphWidthAutoResize, buildUiAction);
            pm.Add(graphWidth, () => timeframeUI.ResizeGraphUI());
            pm.Add(graphTextureSize, () => timeframeUI.RecreateTexture());
            pm.Add(graphMsUpperLimit, () => timeframeUI.UpdateAllTextureColumns());
            pm.Add(graphColorAlternateTint, () => timeframeUI.RecreateTexture());
        }
    
        public override void OnInspectorGUI()
        {
            pm.Do();
        }  
    }
}
#endif


/// timeframeui/Assets/TimeframeUI/Scripts/Stats.cs
﻿namespace Termway.Helper
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    /// <summary>
    /// Compute simple statistic.
    /// Use a array and sorted list to guarantee a O(1) percentile computation.
    /// </summary>
    public class Stats
    {
        /// <summary>
        /// Max population.
        /// </summary>
        public uint PopulationSize { get; private set; }

        /// <summary>
        /// Current index used to populate <see cref="timeframes"/>.
        /// </summary>
        public uint CurrentIndex { get; private set; }

        /// <summary>
        /// Number of times that timeframes data have been replaced.
        /// </summary>
        public uint TotalIteration { get; private set; }

        /// <summary>
        /// Store consecutive timeframes by frame count index value in ms.
        /// </summary>
        float[] timeframes;

        /// <summary>
        /// Sorted times values of <see cref="timeframes"/> via insert sort.
        /// Stats are computed from thoses sorted timeframes value.
        /// </summary>
        List<float> sortedTimeframes;

        /// <summary>
        /// Create the stats object with a given population size..
        /// </summary>
        /// <param name="populationSize">Must be > 0.</param>
        public Stats(uint populationSize)
        {
            if (populationSize == 0)
                throw new ArgumentException("Population size must be at least 1.");

            PopulationSize = populationSize;
            timeframes = new float[populationSize];
            sortedTimeframes = new List<float>((int) populationSize);
        }

        /// <summary>
        /// Pass to true when all data are populated in <see cref="timeframes"/>.
        /// </summary>
        public bool IsPopulated { get { return TotalIteration > 0; } }

        /// <summary>
        /// Recover the last added value.
        /// </summary>
        public float LastAdded { get; private set; }

        /// <summary>
        /// Min recorded value.
        /// </summary>
        public float Min { get { return sortedTimeframes.Any() ? sortedTimeframes.First() : 0; } }

        /// <summary>
        /// Max recorded value.
        /// </summary>
        public float Max { get { return sortedTimeframes.Any() ? sortedTimeframes.Last() : 0; } }

        /// <summary>
        /// Add the value.
        /// </summary>
        /// <param name="value"></param>
        public void AddNext(float value)
        {
            if (IsPopulated && sortedTimeframes.Contains(timeframes[CurrentIndex]))
                sortedTimeframes.Remove(timeframes[CurrentIndex]);

            LastAdded = value;
            timeframes[CurrentIndex] = value;

            //Search the index of the new value in the sorted list and insert it at the right place (insert sort).
            int index = sortedTimeframes.BinarySearch(timeframes[CurrentIndex]);
            index = index >= 0 ? index : ~index;
            sortedTimeframes.Insert(index, timeframes[CurrentIndex]);

            CurrentIndex++;
            if (CurrentIndex >= PopulationSize)
            {
                CurrentIndex = CurrentIndex % PopulationSize;
                TotalIteration++;
            }
        }

        public float Last(uint lastNValues = 0)
        {
            if (lastNValues == 0)
                return LastAdded;

            if(lastNValues >= PopulationSize)
                throw new ArgumentException("lastNValues must be between below PopulationSize. " + lastNValues + "<" + PopulationSize);

            int index = (int) (CurrentIndex - lastNValues - 1);
            return timeframes[(index + 2 * PopulationSize) % PopulationSize];          
        }


        /// <summary>
        /// Compute the average of the timeframe. O(n).
        /// </summary>
        /// <returns>Value is clamped between [1, <see cref="PopulationSize"/>]. 0 means average on all values. </returns>
        public float Average(uint ulastNValues = 0)
        {
            int lastNValues = (int) Math.Min(ulastNValues, PopulationSize);
            lastNValues = lastNValues == 0 ? (int) PopulationSize : lastNValues;  //0 is the same as all values. 
                
            int index = (int) CurrentIndex;

            if (PopulationSize == 1)
                return timeframes[0];

            float average = 0;
            //No negative value for not populated timeframe.
            int minIndexLastNValue = IsPopulated ? index - lastNValues : Math.Max(0, index - lastNValues);
            int minIndex = IsPopulated ? (int) PopulationSize : index;
            int startingIndex = lastNValues == 0 ? Math.Max(0, index - minIndex) : minIndexLastNValue;

            int number = 0;
            for (int tf = startingIndex; tf < index; tf++, number++)
                average += timeframes[(tf + PopulationSize) % PopulationSize];
            return average / Math.Max(1, number);
        }

        /// <summary>
        /// Compute percentile value using index value. O(1).
        /// </summary>
        /// <param name="percentile">Percentage must be between 0 and 100. [0, 100].</param>
        /// <returns></returns>
        public float Percentile(float percentile)
        {
            if (percentile < 0 || percentile > 100)
                throw new ArgumentException("Percentage must be between 0 and 100. Was " + percentile);

            percentile = 100 - percentile;
            uint realRange = IsPopulated ? PopulationSize : CurrentIndex;
            //Round to avoid precision truncate for high range value.
            uint index = (uint) Math.Round(realRange * percentile / 100f); 
            if (sortedTimeframes.Count > index)
                return sortedTimeframes.ElementAt((int)index);
            return timeframes[CurrentIndex];
        }
    }
}


/// timeframeui/Assets/TimeframeUI/Scripts/Helper/Attributes/Vector2RangeAttributes.cs
﻿namespace Termway.Helper
{
    using System;
    using UnityEngine;

    public class Vector2RangeAttribute : PropertyAttribute
    {
        float minX, maxX;
        float minY, maxY;

        public Vector2RangeAttribute(float minX, float maxX, float minY, float maxY)
        {
            this.minX = minX;
            this.maxX = maxX;
            this.minY = minY;
            this.maxY = maxY;
        }

        public Vector2RangeAttribute(float min, float max)
        {
            this.minX = min;
            this.maxX = max;
            this.minY = min;
            this.maxY = max;
        }

        public Vector2 Clamp(Vector2 v)
        {
            return new Vector2
                (
                    Mathf.Clamp(v.x, minX, maxX),
                    Mathf.Clamp(v.y, minY, maxY)
                );
        }
    }

    public class Vector2IntRangeAttribute : PropertyAttribute
    {
        int minX, maxX;
        int minY, maxY;
        string[] tostrings;

        public Vector2IntRangeAttribute(int minX, int maxX, int minY, int maxY)
        {
            this.minX = minX;
            this.maxX = maxX;
            this.minY = minY;
            this.maxY = maxY;

            tostrings = new string[] { "X ∈ [" + minX + ", " + maxX + "]", "Y ∈ [" + minY + ", " + maxY + "]" };
        }

        public Vector2IntRangeAttribute(int min, int max) : this(min, max, min, max) { }

        public Vector2Int Clamp(Vector2Int v)
        {
            return new Vector2Int
                (
                    Math.Min(Math.Max(v.x, minX), maxX),
                    Math.Min(Math.Max(v.y, minY), maxY)
                );
        }

        public int Clamp(int index, int value)
        {
            if (index == 0)
                return ClampX(value);
            else if (index == 1)
                return ClampY(value);
            throw new ArgumentOutOfRangeException("Input index should be 0 or 1 but is " + index);
        }

        public int ClampX(int x)
        {
            return Math.Min(Math.Max(x, minX), maxX);
        }

        public int ClampY(int y)
        {
            return Math.Min(Math.Max(y, minY), maxY);
        }

        public string[] ToStrings()
        {
            return tostrings;
        }
    }
}


/// timeframeui/Assets/TimeframeUI/Scripts/Helper/Attributes/Vector2RangeDrawer.cs
﻿#if UNITY_EDITOR
namespace Termway.Helper
{
    using System.Collections.Generic;
    using UnityEditor;
    using UnityEngine;

    [CustomPropertyDrawer(typeof(Vector2RangeAttribute))]
    public class Vector2RangeAttributeDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            label.tooltip = fieldInfo.GetTooltip();

            Vector2RangeAttribute vector2Range = attribute as Vector2RangeAttribute;
            if (property.propertyType == SerializedPropertyType.Vector2)
            {
                EditorGUI.BeginChangeCheck();
                
                Vector2 vector2Value = EditorGUI.Vector2Field(position, label, property.vector2Value);
                if (EditorGUI.EndChangeCheck())
                    property.vector2Value = vector2Range.Clamp(vector2Value);

            }
            else
                Debug.LogError(typeof(Vector2RangeAttribute).Name + " must be only use for " + typeof(Vector2).Name);
        }

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {   
            return Screen.width < 333 ? (16f + 18f) : 16f; 
        }
    }

    [CustomPropertyDrawer(typeof(Vector2IntRangeAttribute))]
    public class Vector2IntRangeAttributeDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            label.tooltip = fieldInfo.GetTooltip();
            Vector2IntRangeAttribute vector2IntRange = attribute as Vector2IntRangeAttribute;
#if UNITY_2017_2_OR_NEWER
            if (property.propertyType == SerializedPropertyType.Vector2Int)
            {
                EditorGUI.BeginChangeCheck();
                Vector2Int vector2IntValue = EditorGUI.Vector2IntField(position, label, property.vector2IntValue);
                if (EditorGUI.EndChangeCheck())
                    property.vector2IntValue = vector2IntRange.Clamp(vector2IntValue);
            }
#else
            if (property.propertyType == SerializedPropertyType.Generic)
            {
                Rect remainingPosition = EditorGUI.PrefixLabel(position, label);
                List<SerializedProperty> propertiesChildren = property.Children();

                if (position.height > 16f)
                {
                    position.height = 16f;
                    EditorGUI.indentLevel += 1;
                    remainingPosition = EditorGUI.IndentedRect(position);
                    remainingPosition.y += 18f;
                }

                float halfRemainingPositionWidth = remainingPosition.width / 2;
                EditorGUIUtility.labelWidth = 14f;
                remainingPosition.width /= 2;
                EditorGUI.indentLevel = 0;

                string[] labels = { "X", "Y" };
                string[] tooltips = vector2IntRange.ToStrings();

                for (int i = 0; i < 2; i++)
                {
                    EditorGUI.BeginProperty(remainingPosition, new GUIContent(labels[i], tooltips[i]), propertiesChildren[i]);
                    EditorGUI.BeginChangeCheck();
                    int value = EditorGUI.IntField(remainingPosition, new GUIContent(labels[i], tooltips[i]), propertiesChildren[i].intValue);
                    if (EditorGUI.EndChangeCheck())
                        propertiesChildren[i].intValue = vector2IntRange.Clamp(i, value);
                    EditorGUI.EndProperty();
                    remainingPosition.x += halfRemainingPositionWidth;
                }           
            }
#endif
            else
                Debug.Log(typeof(Vector2IntRangeAttribute).Name + " must be only use for " + typeof(Vector2Int).Name);
        }

        // https://catlikecoding.com/unity/tutorials/editor/custom-list/ for multiline ident
        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            return Screen.width < 333 ? (16f + 18f) : 16f;
        }
    }

}
#endif


/// timeframeui/Assets/TimeframeUI/Scripts/Helper/Compatibilities/NameofCompatibility.cs
﻿namespace Termway.Helper
{
    using System;
    using System.Linq.Expressions;

    /// <summary>
    /// Backward compativibity for nameof (pre C# 6) 
    /// Proposed usage : 
    /// Name.Of(() => Type.Member);   => "Member"
    /// Name.Of(Type.Method);   => "Method"
    /// Name.Of<Class>();   => "Class"
    /// </summary>
    public static class Name
    {
        /// <summary>
        /// Usage Name.Of(() => member); => "member"
        /// </summary>
        public static string Of<T>(Expression<Func<T>> member)
        {
            return (member.Body as MemberExpression).Member.Name;
        }

        /// <summary>
        /// Usage : Name.Of((Type t) => t.member); => "member"
        /// Usage : Name.Of<Type, Tmember>(t => t.member); => "member"
        /// </summary>
        public static string Of<Tin, Tout>(Expression<Func<Tin, Tout>> member)
        {
            return (member.Body as MemberExpression).Member.Name;
        }

        /// <summary>
        /// Usage Name.Of<Class>(); => "Class"
        /// </summary>
        public static string Of<T>()
        {
            return typeof(T).Name;
        }
    }
}

/// timeframeui/Assets/TimeframeUI/Scripts/Helper/Compatibilities/Vector2IntCompatibility.cs
﻿//For Vector2Int backward compatibility. Before 2017.2.

#if !UNITY_2017_2_OR_NEWER
namespace Termway.Helper
{
    using UnityEngine; 

    [System.Serializable]
    public struct Vector2Int
    {
        public int x;
        public int y;

        public Vector2Int(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public Vector2Int(Vector2 v)
        {
            x = Mathf.RoundToInt(v.x);
            y = Mathf.RoundToInt(v.y);
        }

        public static implicit operator Vector2(Vector2Int v)
        {
            return new Vector2(v.x, v.y);
        }
    }
}

#if UNITY_EDITOR
namespace Termway.Helper
{
    using System.Collections.Generic;
    using UnityEditor;
    using UnityEngine;

    [CustomPropertyDrawer(typeof(Vector2Int))]
    public class Vector2IntDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            if (property.propertyType == SerializedPropertyType.Generic)
            {
                Rect remainingPosition = EditorGUI.PrefixLabel(position, label);
                List<SerializedProperty> propertiesChildren = property.Children();

                if (position.height > 16f)
                {
                    position.height = 16f;
                    EditorGUI.indentLevel += 1;
                    remainingPosition = EditorGUI.IndentedRect(position);
                    remainingPosition.y += 18f;
                }

                float halfRemainingPositionWidth = remainingPosition.width / 2;
                EditorGUIUtility.labelWidth = 14f;
                remainingPosition.width /= 2;
                EditorGUI.indentLevel = 0;

                string[] labels = { "X", "Y" };

                for (int i = 0; i < 2; i++)
                {
                    EditorGUI.BeginProperty(remainingPosition, new GUIContent(labels[i]), propertiesChildren[i]);
                    propertiesChildren[i].intValue = EditorGUI.IntField(remainingPosition, new GUIContent(labels[i]), propertiesChildren[i].intValue);
                    EditorGUI.EndProperty();
                    remainingPosition.x += halfRemainingPositionWidth;
                }
            }
        }

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            return Screen.width < 333 ? (16f + 18f) : 16f;
        }
    }
}
#endif

#endif

/// timeframeui/Assets/TimeframeUI/Scripts/Helper/Extensions/EnumerableExtensions.cs
﻿namespace Termway.Helper
{
    using System.Collections.Generic;
    using System.Linq;

    public static class EnumerableExtension
    {
        /// <summary>
        /// Parse all enumerable element into a string. 
        /// </summary>
        public static string ToStr<T>(this IEnumerable<T> enumerable, string separator = ";")
        {
            return ToFlattenString(enumerable, separator);
        }

        /// <summary>
        /// Parse all enumerable element into a string. <see cref="ToStr"/> Same Same but Different (Name) but still Same.
        /// </summary>
        public static string ToFlattenString<T>(this IEnumerable<T> enumerable, string separator = ";")
        {
            string[] elements = enumerable.Select(e => e.ToString()).ToArray();
            return string.Join(separator, elements);
        }
    }
}


/// timeframeui/Assets/TimeframeUI/Scripts/Helper/Extensions/FieldInfoExtensions.cs
﻿namespace Termway.Helper
{
    using System.Linq;
    using System.Reflection;

    using UnityEngine;

    public static class FieldInfoExtensions
    {
        /// <summary>
        /// Recover the fieldInfo tooltip text from <see cref="TooltipAttribute "/> or an empty string if there is no tooltip.
        /// </summary>
        public static string GetTooltip(this FieldInfo fieldInfo)
        {
            TooltipAttribute tooltipAttribute = fieldInfo.GetCustomAttributes(typeof(TooltipAttribute), true).FirstOrDefault() as TooltipAttribute;
            return tooltipAttribute == null ? "" : tooltipAttribute.tooltip;
        }
    }
}

/// timeframeui/Assets/TimeframeUI/Scripts/Helper/Extensions/SerializedPropertyExtensions.cs
﻿#if UNITY_EDITOR
namespace Termway.Helper
{
    using UnityEngine;
    using UnityEditor;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;

    public static class SerializedPropertyExtensions
    {
        public static object Value(this SerializedProperty sp)
        {
            switch (sp.propertyType)
            {
                case SerializedPropertyType.Integer:
                case SerializedPropertyType.LayerMask:
                case SerializedPropertyType.ArraySize:          return sp.intValue;
                case SerializedPropertyType.Boolean:            return sp.boolValue;
                case SerializedPropertyType.Float:              return sp.floatValue;
                case SerializedPropertyType.String:             return sp.stringValue;
                case SerializedPropertyType.Color:              return sp.colorValue;
                case SerializedPropertyType.ObjectReference:    return sp.objectReferenceValue;
                case SerializedPropertyType.Enum:               return new KeyValuePair<int, string>(sp.enumValueIndex, sp.enumNames[sp.enumValueIndex]);
                case SerializedPropertyType.Vector2:            return sp.vector2Value;
                case SerializedPropertyType.Vector3:            return sp.vector3Value;
                case SerializedPropertyType.Vector4:            return sp.vector4Value;
                case SerializedPropertyType.Rect:               return sp.rectValue;
                case SerializedPropertyType.Character:          return (char)sp.intValue;
                case SerializedPropertyType.AnimationCurve:     return sp.animationCurveValue;
                case SerializedPropertyType.Bounds:             return sp.boundsValue;
                case SerializedPropertyType.Gradient:           return sp.GradientValue();
                case SerializedPropertyType.Quaternion:         return sp.quaternionValue;
                case SerializedPropertyType.ExposedReference:   return sp.exposedReferenceValue;
#if UNITY_2017_2_OR_NEWER
                case SerializedPropertyType.FixedBufferSize:    return sp.fixedBufferSize;
                case SerializedPropertyType.Vector2Int:         return sp.vector2IntValue;
                case SerializedPropertyType.Vector3Int:         return sp.vector3IntValue;
                case SerializedPropertyType.RectInt:            return sp.rectIntValue;
                case SerializedPropertyType.BoundsInt:          return sp.boundsIntValue;
#endif
                case SerializedPropertyType.Generic:
                default:
                    return GenericValue(sp);
            }
        }

        /// <summary>
        /// Get the value for a Generic SerializedProperty. The SerializedProperty must be an array and have children.
        /// </summary>
        /// <param name="objectReference">if we accept objectReference element.</param>
        /// <returns>The list of objects from the children or elements of the array.</returns>
        static object GenericValue(SerializedProperty serializedProperty, bool objectReference = false)
        {
            if (serializedProperty.isArray)
            {
                List<object> list = new List<object>();
                for (int i = 0; i < serializedProperty.arraySize; i++)
                {
                    SerializedProperty sp = serializedProperty.GetArrayElementAtIndex(i);
                    if (objectReference || sp.propertyType != SerializedPropertyType.ObjectReference)
                        list.Add(sp.Value());
                }
                return list;
            }
            else if (serializedProperty.hasChildren)
            {
                List<object> list = new List<object>();
                List<SerializedProperty> serializedPropertyChildren = serializedProperty.Children();
                foreach (SerializedProperty sp in serializedPropertyChildren)
                    if (objectReference || sp.propertyType != SerializedPropertyType.ObjectReference)
                        list.Add(sp.Value());

                return list;
            }
            else
                return serializedProperty.GetReflectionValue();
        }

        public static object GetReflectionValue(this SerializedProperty serializedProperty)
        {
            MemberInfo[] membersInfo = serializedProperty.serializedObject.targetObject.GetType().GetMember(serializedProperty.name);
            if (membersInfo.Length == 0)
                return null;

            FieldInfo fieldInfo = membersInfo.First() as FieldInfo;
            return fieldInfo.GetValue(serializedProperty.serializedObject.targetObject);
        }


        /// <summary>
        /// Get all the children of a SerializedProperty. Use SerializeProperty iterator method to do so.
        /// </summary>
        public static List<SerializedProperty> Children(this SerializedProperty serializeProperty)
        {
            List<SerializedProperty> spChildren = new List<SerializedProperty>();
            SerializedProperty serializedPropertySibling = serializeProperty.Copy();
            SerializedProperty serializedPropertyChild = serializeProperty.Copy();

            serializedPropertySibling.NextVisible(false);
            //Stop if there is not more element or when the next element is a sibling and not a child.
            while (serializedPropertyChild.NextVisible(true) && !SerializedProperty.EqualContents(serializedPropertySibling, serializedPropertyChild))
                spChildren.Add(serializedPropertyChild.Copy());

            return spChildren;
        }

        /// <summary>
        /// Test equality for SerializedProperty deep copy value. 
        /// Because SerializedProperty.EqualContents only work on SerializedProperty and SerializedProperty.Copy() do not perform a deep copy of the value but serve as an iterator storage.
        /// </summary>
        public static bool IsEquals(this SerializedProperty serializedProperty, object obj)
        {
            object value = serializedProperty.Value();
            return IsEquals(value, obj);
        }

        static bool IsEquals(object objectA, object objectB)
        {
            if (objectA is List<object> && objectB is List<object>)
            {
                List<object> list = objectA as List<object>;
                List<object> list2 = objectB as List<object>;
                if (list.Count != list2.Count)
                    return false;

                for (int i = 0; i < list.Count; i++)
                    if (!IsEquals(list[i], list2[i]))
                        return false;

                return true;
            }
            else
                return objectA.Equals(objectB);
        }

        /// <summary>
        /// When Unity forgot to put a property a public to a method. ("internal Gradient gradientValue")
        /// </summary>
        public static Gradient GradientValue(this SerializedProperty sp)
        {
            PropertyInfo propertyInfo = typeof(SerializedProperty).GetProperty(
                "gradientValue",
                BindingFlags.NonPublic | BindingFlags.Instance,
                null,
                typeof(Gradient),
                new System.Type[0],
                null
            );
            if (propertyInfo == null)
                return null;

            Gradient gradientValue = propertyInfo.GetValue(sp, null) as Gradient;
            return gradientValue;
        }
    }
}
#endif

/// timeframeui/Assets/TimeframeUI/Scripts/Helper/Extensions/RectTransformExtensions.cs
﻿namespace Termway.Helper
{
    using UnityEngine;

    public static class RectTransformExtensions
    {
        public static void Left(this RectTransform rt, float left)
        {
            rt.offsetMin = new Vector2(left, rt.offsetMin.y);
        }

        public static void Bottom(this RectTransform rt, float bottom)
        {
            rt.offsetMin = new Vector2(rt.offsetMin.x, bottom);
        }

        public static void Right(this RectTransform rt, float right)
        {
            rt.offsetMax = new Vector2(-right, rt.offsetMax.y);
        }

        public static void Top(this RectTransform rt, float top)
        {
            rt.offsetMax = new Vector2(rt.offsetMax.x, -top);
        }

        public static void Width(this RectTransform rt, float width)
        {
            rt.sizeDelta = new Vector2(width, rt.sizeDelta.y);
        }

        public static void Height(this RectTransform rt, float height)
        {
            rt.sizeDelta = new Vector2(rt.sizeDelta.x, height);
        }

        public static void PosX(this RectTransform rt, float x)
        {
            rt.anchoredPosition = new Vector2(x, rt.anchoredPosition.y);
        }

        public static void PosY(this RectTransform rt, float y)
        {
            rt.anchoredPosition = new Vector2(rt.anchoredPosition.x, y);
        }
    }
}

/// timeframeui/Assets/TimeframeUI/Scripts/Helper/SerializedPropertyManager.cs
﻿#if UNITY_EDITOR
namespace Termway.Helper
{
    using System;
    using System.Collections.Generic;

    using UnityEditor;
    using UnityEngine;

    /// <summary>
    /// Simplify model (updateAction) and view (editorAction) actions when there is a value modification for a serialized property of a MonoBehaviour.
    /// It give more flexibility than a OnValueChanged attribute but is more verbose.
    /// 
    /// Example :
    /// 
    /// [CustomEditor(typeof(MonoBehaviourExampleEditor))]
    /// public class MonoBehaviourExampleEditor : Editor
    /// {
    ///    SerializedPropertyManager pm;
    ///    void OnEnable()
    ///    {
    ///         MonoBehaviourExample monoBehaviourExample = (MonoBehaviourExample) target;
    ///         floatProperty = serializedObject.FindProperty(Name.Of(() => monoBehaviourExample.floatProperty));
    ///         pm = new SerializedPropertyManager(serializedObject);
    ///         pm.Add(floatProperty,
    ///             () => monoBehaviourExample.FloatAction(),
    ///             () => floatProperty.floatValue = EditorGUILayout.DelayedFloatField("Target Framerate", floatProperty.floatValue));
    ///    }
    ///    public override void OnInspectorGUI()
    ///    {
    ///         pm.Do();
    ///    }
    ///}   
    /// </summary>
    public class SerializedPropertyManager
    {
        List<PropertyBehaviour> propertiesBehaviour;
        HashSet<Action> postAppliedModifiedActions;
        SerializedObject serializedObject;

        public SerializedPropertyManager(SerializedObject serializedObject)
        {
            postAppliedModifiedActions = new HashSet<Action>();
            propertiesBehaviour = new List<PropertyBehaviour>();
            this.serializedObject = serializedObject;
        }

        public void Add(SerializedProperty serializedProperty,
                Action updateAction = null,
                Action editorAction = null)
        {
            propertiesBehaviour.Add(new PropertyBehaviour(serializedProperty, updateAction, editorAction));
        }

        public void Add(SerializedProperty serializedProperty,
              string displayName,
              Action updateAction = null,
              Action editorAction = null)
        {
            propertiesBehaviour.Add(new PropertyBehaviour(serializedProperty, displayName, updateAction, editorAction));
        }

        public void Do()
        {
            postAppliedModifiedActions.Clear();
            serializedObject.Update();

            foreach (PropertyBehaviour propertyBehaviour in propertiesBehaviour)
            {
                EditorGUI.BeginChangeCheck();

                if (propertyBehaviour.EditorAction == null && propertyBehaviour.SerializedProperty != null)
                    EditorGUILayout.PropertyField(propertyBehaviour.SerializedProperty,
                        new GUIContent(propertyBehaviour.DisplayName), true);

                else if (propertyBehaviour.EditorAction != null)
                    propertyBehaviour.EditorAction.Invoke(); // cant use ?.Invoke due to compatibility issue.

                if ((EditorGUI.EndChangeCheck() || propertyBehaviour.HasBeenUpdated) &&
                        propertyBehaviour.UpdateAction != null &&
                        !postAppliedModifiedActions.Contains(propertyBehaviour.UpdateAction))
                {
                    postAppliedModifiedActions.Add(propertyBehaviour.UpdateAction);
                    propertyBehaviour.CurrentValue = propertyBehaviour.SerializedProperty.Value();        
                } 
            }

            serializedObject.ApplyModifiedProperties();

            foreach (Action postAppliedModifiedAction in postAppliedModifiedActions)
                postAppliedModifiedAction();
        }


        class PropertyBehaviour
        {
            public SerializedProperty SerializedProperty { get; set; }
            public Action EditorAction { get; set; }
            public Action UpdateAction { get; set; }
            public string DisplayName { get; set; }
            public object CurrentValue { get; set; }

            public PropertyBehaviour(SerializedProperty serializedProperty,
                Action updateAction = null,
                Action editorAction = null)

            {
                SerializedProperty = serializedProperty;
                UpdateAction = updateAction;
                EditorAction = editorAction;
                DisplayName = serializedProperty.displayName;
                CurrentValue = SerializedProperty.Value();
            }

            public PropertyBehaviour(SerializedProperty serializedProperty,
                string displayName,
                Action updateAction = null,
                Action editorAction = null) : this(serializedProperty, updateAction, editorAction)
            {
                DisplayName = displayName;
            }

            public bool HasBeenUpdated
            {
                get
                {
                    if (CurrentValue == null)               
                        throw new ArgumentNullException("CurrentValue is null " + SerializedProperty.name + ":" + SerializedProperty.propertyType);

                    if (SerializedProperty.propertyType == SerializedPropertyType.Generic)
                        return !SerializedProperty.IsEquals(CurrentValue);
                    
                    return !CurrentValue.Equals(SerializedProperty.Value());
                }
            }

        }
    }

}



#endif


